WatermarkCamera
===============

Android camera app to capture square photo with custom watermark on it.
